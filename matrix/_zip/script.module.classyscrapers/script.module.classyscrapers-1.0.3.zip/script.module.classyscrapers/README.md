# Classy Scrapers

Kodi module `script.module.classyscrapers` — Classy-branded torrent scraper pack for The Crew.

- Base: Viper Scrapers 1.5.0 layout
- Hardened providers (DMM, Mediafusion, Torrentio, TGX/cfscrape)
