# -*- coding: utf-8 -*-
'''
 ***********************************************************
 * The Crew Add-on
 *
 * @file hunter.py
 * @package script.module.thecrew
 *
 * Hunter JavaScript Deobfuscator
 * Based on: https://technicology52263854.wordpress.com/2018/04/29/deobfuscating-hunter-javascript/
 *
 * @copyright (c) 2023-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 ********************************************************cm*
'''
import re

_0xce1e="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/"
def __duf(d,e,f):
    g = list(_0xce1e)
    h = g[0:e]
    i = g[0:f]
    d = list(d)[::-1]
    j = 0
    for c,b in enumerate(d):
        if b in h:
            j = j + h.index(b)*e**c

    k = ""
    while j > 0:
        k = i[j%f] + k
        j = (j - (j%f))//f

    return int(k) or 0

def hunter(h,u,n,t,e,r):
    r = ""
    i = 0
    while i < len(h):
        j = 0
        s = ""
        while h[i] is not n[e]:
            s = ''.join([s,h[i]])
            i = i + 1

        while j < len(n):
            s = s.replace(n[j],str(j))
            j = j + 1

        r = ''.join([r,''.join(map(chr, [__duf(s,e,10) - t]))])
        i = i + 1

    return r
