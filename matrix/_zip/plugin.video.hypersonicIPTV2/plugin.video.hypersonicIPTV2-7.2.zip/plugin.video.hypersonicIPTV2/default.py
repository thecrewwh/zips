 #############Imports#############
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs, base64,os,re,unicodedata,requests,time,string,sys,urllib.request,urllib.parse,urllib.error,json,datetime,zipfile,shutil,plugintools
from resources.modules import client,control,tools,shortlinks
from resources.ivue import ivuesetup
from datetime import date
import xml.etree.ElementTree as ElementTree
import difflib
#################################

#############Defined Strings#############
addon_id      = 'plugin.video.hypersonicIPTV2'
selfAddon     = xbmcaddon.Addon(id=addon_id)
selfAddon     = xbmcaddon.Addon(id=addon_id)
icon          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart        = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'fanart.jpg'))
apk           = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon1.png'))
search2       = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon3.png'))
system        = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon5.png'))
airing        = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon2.png'))
cache         = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon4.png'))
speed         = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/icon6.png'))
account       = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/icons/account.png'))

username     = control.setting('Username')
password     = control.setting('Password')
adultset     = control.setting('Adult.Set')
adultpwset      = control.setting('Adult.PWSet')
adultpw = control.setting('Adult.PW')

host         = 'http://live.hypersonic-tv.com'
port         = '80'

live_url     = '%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories'%(host,port,username,password)
vod_url      = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(host,port,username,password)
series_url   = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories'%(host,port,username,password)
panel_api    = '%s:%s/panel_api.php?username=%s&password=%s'%(host,port,username,password)
play_url     = '%s:%s/live/%s/%s/'%(host,port,username,password)

#CATEGORIES
All='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&'%(host,port,username,password)
USA_Entertainment='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1'%(host,port,username,password)
USA_Sports='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=689'%(host,port,username,password)
USA_SPORTS_REGIONALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1159'%(host,port,username,password)
UK_Entertainment='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=691'%(host,port,username,password)
UK_Sports_2='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=690'%(host,port,username,password)
UK_Movies='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=693'%(host,port,username,password)
UK_News='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1214'%(host,port,username,password)
UK_Documentaries='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=692'%(host,port,username,password)
UK_Kids='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=694'%(host,port,username,password)
New_Canada='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1385'%(host,port,username,password)
Canada='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=665'%(host,port,username,password)
Canada_News='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1186'%(host,port,username,password)
Canada_Movies='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1177'%(host,port,username,password)
Canada_Reality='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1178'%(host,port,username,password)
Canada_Kids='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1179'%(host,port,username,password)
Canadian_Sports='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=713'%(host,port,username,password)
EPL_SPFL_Eleven_Sports='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1383'%(host,port,username,password)
CARIBBEAN='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1213'%(host,port,username,password)
PPV___Live_Events='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=41'%(host,port,username,password)
ESPN_PLUS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1384'%(host,port,username,password)
Music_Choice='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1392'%(host,port,username,password)
TwentyFourSeven='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=18'%(host,port,username,password)
NBC_GOLD___Premier_League='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1188'%(host,port,username,password)
All_Sports='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=16'%(host,port,username,password)
NFL_Package='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=10'%(host,port,username,password)
NHL_Package='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=11'%(host,port,username,password)
NBA_Package='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1484'%(host,port,username,password)
MLB_Package='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1210'%(host,port,username,password)
MLB_Backup_1='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1210'%(host,port,username,password)
MLS_Package='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1518'%(host,port,username,password)
NCAAB='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=59'%(host,port,username,password)
NCAAF='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1394'%(host,port,username,password)
International_Sports='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=9'%(host,port,username,password)
SOUTH_AMERICA='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1189'%(host,port,username,password)
Australia='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1184'%(host,port,username,password)
Africa='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=43'%(host,port,username,password)
Albania='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=44'%(host,port,username,password)
Arabic='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=56'%(host,port,username,password)
Armenia='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=17'%(host,port,username,password)
Belgium='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1320'%(host,port,username,password)
Brazil='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=45'%(host,port,username,password)
Bulgaria='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=53'%(host,port,username,password)
Czech_Republic='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=26'%(host,port,username,password)
USNEWS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=65'%(host,port,username,password)
EX_YU='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=28'%(host,port,username,password)
EGYPT='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1367'%(host,port,username,password)
France='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=47'%(host,port,username,password)
German='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=52'%(host,port,username,password)
Greek='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=29'%(host,port,username,password)
Hungary='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=46'%(host,port,username,password)
India='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=48'%(host,port,username,password)
Indonesia='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1370'%(host,port,username,password)
Irish='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1180'%(host,port,username,password)
Israel='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1319'%(host,port,username,password)
direct_test='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=662'%(host,port,username,password)
Japan='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=34'%(host,port,username,password)
Korea='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=35'%(host,port,username,password)
Latino='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=24'%(host,port,username,password)
Netherlands='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=36'%(host,port,username,password)
Norway='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1382'%(host,port,username,password)
Pakistan='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=54'%(host,port,username,password)
Persian='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=22'%(host,port,username,password)
Philippines='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1318'%(host,port,username,password)
Polish='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=21'%(host,port,username,password)
Portugal='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=55'%(host,port,username,password)
Romania='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=50'%(host,port,username,password)
Russia='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=49'%(host,port,username,password)
Spain='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1174'%(host,port,username,password)
Denmark='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=38'%(host,port,username,password)
Sweden='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1330'%(host,port,username,password)
Italy='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=33'%(host,port,username,password)
Turkish='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=40'%(host,port,username,password)
Adult='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=23'%(host,port,username,password)
twentyfourseven_Kids='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1488'%(host,port,username,password)
twentyfourseven_Movies='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=709'%(host,port,username,password)
twentyfourseven_AG='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1477'%(host,port,username,password)
twentyfourseven_HN='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1478'%(host,port,username,password)
twentyfourseven_OU='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1479'%(host,port,username,password)
twentyfourseven_VZ='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1480'%(host,port,username,password)
twentyfourseven_ADULT='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1395'%(host,port,username,password)
twentyfourseven_Latin='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1528'%(host,port,username,password)
USA_Reality='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=706'%(host,port,username,password)
ABC_LOCALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1529'%(host,port,username,password)
CBS_LOCALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1530'%(host,port,username,password)
FOX_LOCALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1531'%(host,port,username,password)
NBC_LOCALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1532'%(host,port,username,password)
USA_KIDS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=702'%(host,port,username,password)
USA__Movies='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=707'%(host,port,username,password)
USA_Music='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1216'%(host,port,username,password)
Nascar='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1401'%(host,port,username,password)
USA_FOX_SPORTS_REGIONALS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1520'%(host,port,username,password)
SKY_SPORTS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1525'%(host,port,username,password)
BT_SPORTS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1526'%(host,port,username,password)
BBC_RED_BUTTON_SPORTS='%s:%s/enigma2.php?username=%s&password=%s&type=get_live_streams&cat_id=1527'%(host,port,username,password)

Guide    = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/catchup', 'guide.xml'))
GuideLoc = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/catchup', 'g'))

advanced_settings           =  xbmcvfs.translatePath('special://home/addons/'+addon_id+'/resources/advanced_settings')
advanced_settings_target    =  xbmcvfs.translatePath(os.path.join('special://home/userdata','advancedsettings.xml'))

USER_DATA        = xbmcvfs.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA       = xbmcvfs.translatePath(os.path.join(USER_DATA,'addon_data'))
tvprotvfol       = xbmcvfs.translatePath(os.path.join(ADDON_DATA,'plugin.video.hypersonicIPTV2'))
tvprotvset       = xbmcvfs.translatePath(os.path.join(ADDON_DATA,'settings.xml'))
ini              = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/ivue','addons_index.ini'))
inizip           = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.hypersonicIPTV2/resources/ivue','addons_index.zip'))
tmpini           = xbmcvfs.translatePath(os.path.join('special://home/userdata',''))
ivuetarget       = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/script.ivueguide/'))
ivueaddons2ini   = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/script.ivueguide/addons2.ini'))
ivuecreate       = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.IVUEcreator/'))
ivuecreateini    = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.IVUEcreator/addons_index.ini'))
PVRSimple        = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/pvr.iptvsimple/settings.xml'))
databasePath     = xbmcvfs.translatePath('special://profile/addon_data/script.ivueguide')
subPath          = xbmcvfs.translatePath('special://profile/addon_data/script.ivueguide/resources/ini')
pyPath           = xbmcvfs.translatePath('special://profile/addon_data/script.ivueguide/resources/subs')
setupPath        = xbmcvfs.translatePath('special://profile/addon_data/script.ivueguide/resources/guide_setups')
tvproaddons2ini  = xbmcvfs.translatePath('special://profile/addon_data/script.ivueguide/addons2.ini')
dialog           = xbmcgui.Dialog()
#########################################
def start():
    if username=="":
        user = userpopup()
        passw= passpopup()
        control.setSetting('Username',user)
        control.setSetting('Password',passw)
        xbmc.executebuiltin('Container.Refresh')
        auth = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(host,port,user,passw)
        auth = tools.OPEN_URL(auth)
        if auth == "":
            line1 = "[COLOR red]Incorrect Login Details![/COLOR]"
            line2 = "Please Re-enter" 
            line3 = "To unlock your TV PRO go to:[COLORlime] https://subscribe.hypersonic-tv.com[/COLOR]" 
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', line1, line2, line3)
            start()
        else:
            line1 = "[COLOR lime]Login Successfull![/COLOR]"
            line2 = "Welcome to [COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]" 
            line3 = ('[COLOR blue]%s[/COLOR]'%user)
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', line1 + '\n' + line2 + '\n' + line3)
            addonsettings('ADS2','')
            adult_settings()
            xbmc.executebuiltin('Container.Refresh')
            home()
    else:
        auth = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(host,port,username,password)
        auth = tools.OPEN_URL(auth)
        if not auth=="":
            tools.addDir('[B][COLOR yellow]Video On Demand App[/COLOR][/B]','','',apk,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            tools.addDir('[COLOR white]LIVE TV[/COLOR]','live',1,airing,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            tools.addDir('[COLOR white]SEARCH CHANNELS[/COLOR]','url',5,search2,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            tools.addDir('[COLOR white]CLEAR CACHE[/COLOR]','CC',10,cache,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            tools.addDir('[COLOR white]TOOLS[/COLOR]','url',8,system,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            tools.addDir('[COLORwhite]MY ACCOUNT[/COLOR]','url',6,icon,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
            plugintools.set_view( plugintools.LIST )
            setView()
def home():
    tools.addDir('[B][COLOR yellow]Video On Demand App[/COLOR][/B]','','',apk,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR white]LIVE TV[/COLOR]','live',1,airing,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR white]SEARCH CHANNELS[/COLOR]','url',5,search2,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR white]CLEAR CACHE[/COLOR]','CC',10,cache,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR white]TOOLS[/COLOR]','url',8,system,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLORwhite]MY ACCOUNT[/COLOR]','url',6,icon,fanart,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    plugintools.set_view( plugintools.LIST )
    setView()

    
def guides():
    if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
        tools.addDir('[COLOR white]Simple PVR Client TV Guide[/COLOR]','pvr',7,guide,fanart,'')
    if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
        tools.addDir('[COLOR white]Simple PVR Client Channels Guide[/COLOR]','pvr',45,icon,fanart,'')
    tools.addDir('[COLOR white]Setup Simple PVR[/COLOR]','tv',11,guide,fanart,'')
    tools.addDir('[COLOR white]iVue TV Guide[/COLOR]','pvr',44,guide,fanart,'')
    tools.addDir('[COLOR white]Setup iVue TV Guide -Old-[/COLOR]','tv',15,guide,fanart,'')
    tools.addDir('[COLOR white]Setup iVue TV Guide -New-[/COLOR]','tv',36,guide,fanart,'')
    tools.addDir('[COLOR white]Reboot iVue TV Guide[/COLOR]','url',20,guide,fanart,'')

    
def settingsmenu():
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Settings[/COLOR]','tv',39,icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Edit Advanced Settings[/COLOR]','ADS',10,icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Speed Test[/COLOR]','ST',10,speed,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    plugintools.set_view( plugintools.MOVIES )

                                       
def SoftReset():
    clearFiles = ["guides.ini", "addons.ini", "guide.xml", "amylist.xml", "teamexpat.xml", "otttv.xml", "guide2.xml", "uk3.xml", "guide3.xmltv", "master.xml"]
    for root, dirs, files in os.walk(databasePath,topdown=True):
        dirs[:] = [d for d in dirs]
        for name in files:
            if name in clearFiles:
                try:
                    os.remove(os.path.join(root,name))
                except:
                    dialog.ok('Soft Reset', 'Error Removing ' + str(name),'')
                    pass
            else:
                continue
    dialog.ok('Ivue guide Soft reset', 'Please restart iVue TV Guide ','for changes to take effect.')
    home()


def DESTROY_PATH(path):
    shutil.rmtree(path, ignore_errors=True)

def exit():
    xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
    if os.path.exists(tvprotvfol):   
        DESTROY_PATH(tvprotvfol)

        
def livecategory(url):
    
    open = tools.OPEN_URL(live_url)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        name = tools.regex_from_to(a,'<title>','</title>')
        name = base64.b64decode(name)
        url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
        tools.addDir(name,url1,2,icon,fanart,'')
        plugintools.set_view( plugintools.LIST )
        
def Livelist(url):
    open = tools.OPEN_URL(url)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        name = tools.regex_from_to(a,'<title>','</title>')
        name = base64.b64decode(name)
        xbmc.log(str(name))
        try:
            name = re.sub('\[.*?min ','-',name)
        except:
            pass
        thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
        url1  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
        desc = tools.regex_from_to(a,'<description>','</description>')
        tools.addDir(name,url1,4,thumb,fanart,base64.b64decode(desc))
    plugintools.set_view( plugintools.LIST )
    
def LiveInfolist(url):
    open = tools.OPEN_URL(url)
    all_cats = tools.regex_get_all(open,'<channel>','</channel>')
    for a in all_cats:
        name = tools.regex_from_to(a,'<title>','</title>')
        name = base64.b64decode(name)
        xbmc.log(str(name))
        try:
            name = re.sub('\[.*?min ','-',name)
        except:
            pass
        thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
        url1  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
        desc = tools.regex_from_to(a,'<description>','</description>')
        tools.addDir(name,url1,4,thumb,fanart,base64.b64decode(desc))
    plugintools.set_view( plugintools.EPISODES )
        
        
##########################################


def ivuetvguide():
    if xbmc.getCondVisibility('System.HasAddon(script.ivueguide)'):
        if not os.path.exists(tvproaddons2ini):
            IVUEtvguidesetup()
        else:
            EXIT()
            xbmc.executebuiltin('RunAddon(script.ivueguide)')
        
def simpletvguide():
    if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
        if not os.path.exists(PVRSimple):
            SIMPLEtvguidesetup()
        else:
            EXIT()
            xbmc.executebuiltin('ActivateWindow(TVGuide)')
            
def simplechannels():
    if xbmc.getCondVisibility('System.HasAddon(pvr.iptvsimple)'):
        if not os.path.exists(PVRSimple):
            SIMPLEtvguidesetup()
        else:
            EXIT()
            xbmc.executebuiltin('ActivateWindow(TVChannels)')
            
def EXIT():
    xbmc.executebuiltin("XBMC.Container.Update(path,replace)")
    xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
                
def stream_video(url):
    if adultpwset == "true":
        a = 'XO', 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx','xx'
        if any(s in name for s in a):
            text = control.inputDialog(heading='Enter Adult Password:')
            if text ==control.setting('Adult.PW'):
                url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
                liz = xbmcgui.ListItem('')
                liz.setArt({ 'thumb': iconimage, 'icon': iconimage, 'fanart': fanart}) 
                liz.setInfo(type='Video', infoLabels={'Title': '', 'Plot': ''})
                liz.setProperty('IsPlayable','true')
                liz.setPath(str(url))
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
            else:
                xbmc.executebuiltin(('XBMC.Notification("Parental Lock", "Incorrect Password!", 2000)'))
                return
        else:
            url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
            liz = xbmcgui.ListItem('')
            liz.setArt({ 'thumb': iconimage, 'icon': iconimage, 'fanart': fanart}) 
            liz.setInfo(type='Video', infoLabels={'Title': '', 'Plot': ''})
            liz.setProperty('IsPlayable','true')
            liz.setPath(str(url))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        
    else:
        url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
        liz = xbmcgui.ListItem('')
        liz.setArt({ 'thumb': iconimage, 'icon': iconimage, 'fanart': fanart}) 
        liz.setInfo(type='Video', infoLabels={'Title': '', 'Plot': ''})
        liz.setProperty('IsPlayable','true')
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    
    
def searchdialog():
    search = control.inputDialog(heading='Search [COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR] :')
    if search=="":
        return
    else:
        return search

    
def search():
    if mode==3:
        return False
    text = searchdialog()
    if not text:
        xbmc.executebuiltin("XBMC.Notification([COLORlime][B][I]Search is Empty[/I][/B][/COLOR],Aborting search,4000,"+icon+")")
        return
    xbmc.log(str(text))
    open = tools.OPEN_URL(panel_api)
    all_chans = tools.regex_get_all(open,'{"num":','epg')
    for a in all_chans:
        name = tools.regex_from_to(a,'name":"','"').replace('\/','/')
        url  = tools.regex_from_to(a,'"stream_id":"','"')
        thumb= tools.regex_from_to(a,'stream_icon":"','"').replace('\/','/')
        if text in name.lower():
            tools.addDir(name,play_url+url+'.ts',4,thumb,fanart,'')
        elif text not in name.lower() and text in name:
            tools.addDir(name,play_url+url+'.ts',4,thumb,fanart,'')

    

def addonsettings(url,description):
    if   url =="CC":
        tools.clear_cache()
    elif url =="AS":
        xbmc.executebuiltin('Addon.OpenSettings(%s)'%addon_id)
    elif url =="ADS":
        dialog = xbmcgui.Dialog().select('Edit Advanced Settings', ['[COLOR dodgerblue]* [/COLOR][COLOR lime][I]Amazon Firestick[/I][/COLOR]','[COLOR dodgerblue]* [/COLOR][COLOR lime][I]2GB Ram or Higher[/I][/COLOR]','[COLOR dodgerblue]* [/COLOR][COLOR lime][I]Zero Cache[/I][/COLOR]','[COLOR dodgerblue]* [/COLOR][COLOR lime][I]Nvidia Shield[/I][/COLOR]','[COLOR dodgerblue]* [/COLOR][COLOR lime][I]Disable Advanced Settings[/I][/COLOR]'])
        if dialog==0:
            advancedsettings('stick')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==1:
            advancedsettings('firetv')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==2:
            advancedsettings('lessthan')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==3:
            advancedsettings('morethan')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==4:
            advancedsettings('shield')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==5:
            advancedsettings('remove')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Advanced Settings Removed[/COLOR]')
    elif url =="ADS2":
        dialog = xbmcgui.Dialog().select('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]  Select Your Device', ['[COLOR lime][I]Amazon Firestick[/I][/COLOR]','[COLOR lime][I]2GB Ram or Higher[/I][/COLOR]','[COLOR lime][I]Zero Cache[/I][/COLOR]','[COLOR lime][I]Nvidia Shield[/I][/COLOR]'])
        if dialog==0:
            advancedsettings('stick')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==1:
            advancedsettings('firetv')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==2:
            advancedsettings('lessthan')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==3:
            advancedsettings('morethan')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
        elif dialog==4:
            advancedsettings('shield')
            xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLOR lime]Set Advanced Settings[/COLOR]')
    elif url =="tv":
        ivueint()

    elif url =="ST":
        try:
            xbmcaddon.Addon(id = 'script.speedtester')
            xbmc.executebuiltin('RunAddon("script.speedtester")')
        except:
            xbmc.executebuiltin('InstallAddon("script.speedtester")')
            xbmc.executebuiltin('RunAddon("script.speedtester")')
    elif url =="META":
        if 'ON' in description:
            xbmcaddon.Addon().setSetting('meta','false')
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcaddon.Addon().setSetting('meta','true')
            xbmc.executebuiltin('Container.Refresh')
    elif url =="LO":
        xbmcaddon.Addon().setSetting('Username','')
        xbmcaddon.Addon().setSetting('Password','')
        xbmc.executebuiltin('XBMC.ActivateWindow(Videos,addons://sources/video/)')
        xbmc.executebuiltin('Container.Refresh')
    elif url =="UPDATE":
        if 'ON' in description:
            xbmcaddon.Addon().setSetting('update','false')
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcaddon.Addon().setSetting('update','true')
            xbmc.executebuiltin('Container.Refresh')
    
        
def advancedsettings(device):
    if device == 'stick':
        file = open(os.path.join(advanced_settings, 'stick.xml'))
    elif device == 'firetv':
        file = open(os.path.join(advanced_settings, 'firetv.xml'))
    elif device == 'lessthan':
        file = open(os.path.join(advanced_settings, 'zero.xml'))
    elif device == 'morethan':
        file = open(os.path.join(advanced_settings, 'shield.xml'))
    elif device == 'remove':
        os.remove(advanced_settings_target)
    
    try:
        read = file.read()
        f = open(advanced_settings_target, mode='w+')
        f.write(read)
        f.close()
    except:
        pass
        
    
def pvrsetup():
    correctPVR()
    killxbmc()
    return
        
        
def asettings():
    choice = xbmcgui.Dialog().yesno('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', 'Please Select The RAM Size of Your Device', yeslabel='Less than 1GB RAM', nolabel='More than 1GB RAM')
    if choice:
        lessthan()
    else:
        morethan()
    

def morethan():
        file = open(os.path.join(advanced_settings, 'shield.xml'))
        a = file.read()
        f = open(advanced_settings_target, mode='w+')
        f.write(a)
        f.close()

        
def lessthan():
        file = open(os.path.join(advanced_settings, 'zero.xml'))
        a = file.read()
        f = open(advanced_settings_target, mode='w+')
        f.write(a)
        f.close()
        
        
def userpopup():
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading('Enter Username')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        text = kb.getText()
        return text
    else:
        return False

        
def passpopup():
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading('Enter Password')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        text = kb.getText()
        return text
    else:
        return False
        
        
def accountinfo():
    data = json.load(urllib.request.urlopen(panel_api))
    null = ["0", " " , "null"]
    today = datetime.date.today()
    x=data['user_info']
    Username = x['username']
    Status = x['status']
    Creation = x['created_at']
    Created = datetime.datetime.fromtimestamp(int(Creation)).strftime('%H:%M %m/%d/%Y')
    Current = x['active_cons']
    Max = x['max_connections']
    Expiry = x['exp_date']
    if Expiry == None:
        Expired = 'Never'
    else:
        Expired = datetime.datetime.fromtimestamp(int(Expiry)).strftime('%H:%M %m/%d/%Y')
    tools.addDir('[COLOR dodgerblue]   Hypersonic [COLOR white]IPTV2[/COLOR]','','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Username :[/COLOR] '+Username,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Expire Date:[/COLOR] '+Expired,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Account Status :[/COLOR] '+Status,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Current Connections:[/COLOR] '+Current,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Allowed Connections:[/COLOR] '+Max,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Created:[/COLOR] '+Created,'','',icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR][CR][COLORwhite]For instant help join us on the Telegram group please.[CR]You are important to us.[/COLOR][CR][COLOR lime]https://t.me/joinchat/[CR]Qu56Rg8_i5Dm7zmV[/COLOR]')
    tools.addDir('[COLOR lime]* [/COLOR][COLOR white]Log Out[/COLOR]','LO',10,icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    tools.addDir('To reactivate account please visit:[CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR]',All,2,icon,account,'[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR][CR][COLOR white]DISCOVER THE FUTURE OF LIVE TV[/COLOR][CR][COLORlime]https://subscribe.hypersonic-tv.com[/COLOR][CR][B][COLOR yellow]Please download our APP for VOD[/COLOR][/B][CR][COLOR white]FileLinked code: 60517827[CR][COLOR lime]http://hypersonic-tv.com/[CR]hypersonic.apk[/COLOR]')
    plugintools.set_view( plugintools.MOVIES )

    
def correctPVR():

    addon = xbmcaddon.Addon('plugin.video.hypersonicIPTV2')
    username_text = addon.getSetting(id='Username')
    password_text = addon.getSetting(id='Password')
    jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
    IPTVon     = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
    nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
    loginurl   = "http://live.hypersonic-tv.com:83/get.php?username=" + username_text + "&password=" + password_text + "&type=m3u_plus&output=ts"
    EPGurl     = "http://live.hypersonic-tv.com:83/xmltv.php?username=" + username_text + "&password=" + password_text

    xbmc.executeJSONRPC(jsonSetPVR)
    xbmc.executeJSONRPC(IPTVon)
    xbmc.executeJSONRPC(nulldemo)
    
    moist = xbmcaddon.Addon('pvr.iptvsimple')
    moist.setSetting(id='m3uUrl', value=loginurl)
    moist.setSetting(id='epgUrl', value=EPGurl)
    moist.setSetting(id='m3uCache', value="false")
    moist.setSetting(id='epgCache', value="false")
    
def ivueint():
    ivuesetup.iVueInt()
    xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', 'iVue Integration Complete')
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.IVUEcreator/update_addon/plugin.video.hypersonicIPTV2",return)')
    xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
    
def ivueint2():
    ivuesetup.iVueInt2()
    xbmcgui.Dialog().ok('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]', '[COLORlime]iVue Integration Complete[/COLOR]')
    home()
    
    
def SIMPLEtvguidesetup():
    dialog = xbmcgui.Dialog().yesno('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]','[COLORlime]Would you like us to setup Simple PVR Guide for you?[/COLOR]')
    if dialog:
        pvrsetup()
    else:
        home()
        
def IVUEtvguidesetup():
    dialog = xbmcgui.Dialog().yesno('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]','[COLORlime]Would You like us to Setup iVue TV Guide for You?[/COLOR]')
    if dialog:
        ivueint()
    else:
        home()
        
def ivue_settings():
    xbmc.executebuiltin("Addon.OpenSettings(script.ivueguide)")

def HypersonicIPTV2_settings():
    xbmc.executebuiltin("Addon.OpenSettings(plugin.video.hypersonicIPTV2)")

    
def setView():
    xbmc.executebuiltin("Container.SetViewMode(50)")
    
def killxbmc(over=None):
    killdialog = xbmcgui.Dialog().yesno('Force Close Kodi', '[COLOR white]You are about to close Kodi', 'Would you like to continue?[/COLOR]', nolabel='[B][COLOR red] No Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Force Close Kodi[/COLOR][/B]')
    if killdialog:
        os._exit(1)
    else:
        home()
        
def adultpopup():
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading('[COLORlime]Enter Adult Password[/COLOR]')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        text = kb.getText()
        return text
    else:
        return False

def adult_settings():
    dialog = xbmcgui.Dialog().yesno('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]','[COLORlime]Would you like to HIDE[/COLOR] [COLOR deeppink]Adult Menu[/COLOR]?', '[COLORlime]You can always change this in settings later on.[/COLOR]')
    if dialog:
        control.setSetting('Adult.Set','true')
        pass
    else:
        control.setSetting('Adult.Set','false')
        pass
    dialog = xbmcgui.Dialog().yesno('[COLOR dodgerblue]Hypersonic [COLOR white]IPTV2[/COLOR]','[COLORlime]Would you like to PASSWORD PROTECT[/COLOR] [COLOR deeppink]Adult Channels[/COLOR]?', '[COLORlime]You can always change this in settings later on.[/COLOR]')
    if dialog:
        control.setSetting('Adult.PWSet','true')
        adulter = adultpopup()
        control.setSetting('Adult.PW',adulter)
    else:
        control.setSetting('Adult.PWSet','false')
        pass
        

def testarea():
    tvstreamscat   =  xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.hypersonicIPTV2/categories.db'))
    channels = []
    
    if os.path.isfile(tvstreamscat):
        os.remove(tvstreamscat)

    
    list_a = tools.OPEN_URL(live_url)
    all_chan = tools.regex_get_all(list_a,'<channel>','</channel>')
    for a in all_chan:
            name = tools.regex_from_to(a,'<title>','</title>')
            name = base64.b64decode(name).decode(utf-8)
            name = re.sub(' ','_',name)
            name = re.sub('&','_',name)
            name = re.sub('\/','_',name)
            name = re.sub('\+','_',name)
            xbmc.log(str(name))
            try:
                name = re.sub('\[.*?min ','-',name)
            except:
                pass
            catnum  = tools.regex_from_to(a,'<category_id>','</category_id>')
            line = "%s = %s\n"%(name, catnum)
            channels.append(line)
                    
    for item3 in channels:
        f = open(tvstreamscat, mode='a')
        f.write(item3)
        f.close()
        
       
        
def changenumbers(s):

    numbers = {'1' : 'one' ,'2' : 'two', '3' : 'three', '4':'four', '5' : 'five' ,'6' : 'six' ,
               '7' : 'seven', '8' : 'eight', '9':'nine', '10' : 'ten', '11':'eleven', '12' : 'twelve',}

    for src, target in numbers.items():
        if src in s:
            s = s.replace(src, target)

    return s

def num2day(num):
    if num =="0":
        day = 'monday'
    elif num=="1":
        day = 'tuesday'
    elif num=="2":
        day = 'wednesday'
    elif num=="3":
        day = 'thursday'
    elif num=="4":
        day = 'friday'
    elif num=="5":
        day = 'saturday'
    elif num=="6":
        day = 'sunday'
    return day
    
setView()
params=tools.get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None

try:
    url=urllib.parse.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.parse.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    description=urllib.parse.unquote_plus(params["description"])
except:
    pass
try:
    query=urllib.parse.unquote_plus(params["query"])
except:
    pass
try:
    type=urllib.parse.unquote_plus(params["type"])
except:
    pass

if mode==None or url==None or len(url)<1:
    start()

elif mode==1:
    livecategory(url)
    
elif mode==2:
    Livelist(url)
    
elif mode==3:
    vod(url)
    
elif mode==4:
    stream_video(url)
    
elif mode==5:
    search()
    
elif mode==6:
    accountinfo()
    
elif mode==7:
    simpletvguide()
    
elif mode==8:
    settingsmenu()
    
elif mode==9:
    xbmc.executebuiltin('ActivateWindow(busydialog)')
    tools.Trailer().play(url) 
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    
elif mode==10:
    addonsettings(url,description)
    
elif mode==11:
    SIMPLEtvguidesetup()
    
elif mode==15:
    ivueint()
    
elif mode==17:
    shortlinks.Get()
    
elif mode==19:
    get()
    
elif mode==20:
    SoftReset()
    
elif mode==25:
    LiveInfolist(url)
    
elif mode==27:
    guides()
    
elif mode==36:
    ivueint2()
    
elif mode==37:
    series(url)

elif mode==38:
    ivue_settings()
    
elif mode==39:
    HypersonicIPTV2_settings()
    
elif mode==40:
    simpletvguide()
    
elif mode==44:
    ivuetvguide()
    
elif mode==45:    
    simplechannels()
    
    
    



xbmcplugin.endOfDirectory(int(sys.argv[1]))
