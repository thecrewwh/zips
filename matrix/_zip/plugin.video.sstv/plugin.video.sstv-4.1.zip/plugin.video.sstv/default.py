import xbmcvfs
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import urllib.parse
import requests
import sys
import time
import os
import json
import m3u8

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])

BASE_URL = ADDON.getSetting('base_url')
USERNAME = ADDON.getSetting('username')
PASSWORD = ADDON.getSetting('password')
FILTER_ADULT = ADDON.getSettingBool('filter_adult')
ADULT_KEYWORDS = ['xxx', 'adult', 'porn', 'erotic']

try:
    CACHE_EXPIRATION = int(ADDON.getSetting('cache_expiration'))
except (ValueError, TypeError):
    CACHE_EXPIRATION = 3600

CACHE_FILE = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'cache.json')
try:
    if not os.path.exists(os.path.dirname(CACHE_FILE)):
        os.makedirs(os.path.dirname(CACHE_FILE))
except OSError as e:
    xbmc.log(f"Error creating cache directory: {e}", level=xbmc.LOGERROR)

def load_cache():
    if not os.path.exists(CACHE_FILE):
        log_debug("Cache file does not exist. Returning empty cache.")
        return {}
    try:
        with open(CACHE_FILE, 'r') as f:
            log_debug("Cache file loaded successfully.")
            return json.load(f)
    except (IOError, json.JSONDecodeError) as e:
        log_debug(f"Error loading cache: {e}")
        return {}

def save_cache(cache):
    try:
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache, f)
            log_debug("Cache saved successfully.")
    except IOError as e:
        log_debug(f"Error saving cache: {e}")

def get_cached_data(key):
    cache = load_cache()
    if key in cache:
        entry = cache[key]
        if time.time() - entry['timestamp'] < CACHE_EXPIRATION:
            log_debug(f"Cache hit for key: {key}")
            return entry['data']
        else:
            log_debug(f"Cache expired for key: {key}")
    else:
        log_debug(f"Cache miss for key: {key}")
    return None

def set_cache(key, data):
    cache = load_cache()
    cache[key] = {'data': data, 'timestamp': time.time()}
    save_cache(cache)

def request_with_cache(endpoint):
    if not validate_settings():
        raise ValueError("Invalid settings. Ensure Base URL, Username, and Password are configured.")
    
    cache_key = endpoint
    cached_data = get_cached_data(cache_key)
    if cached_data:
        log_debug(f"Using cached data for endpoint: {endpoint}")
        return cached_data

    try:
        params = {'username': USERNAME, 'password': PASSWORD}
        url = f"{BASE_URL}{endpoint}"
        log_debug(f"Requesting URL: {url} with params: {params}")
        response = requests.get(url, params=params, headers={'User-Agent': 'KodiAddon/1.0'})
        response.raise_for_status()
        data = response.json()
        set_cache(cache_key, data)
        return data
    except requests.exceptions.RequestException as e:
        log_debug(f"API Request Failed: {e}")
        raise

def clear_cache():
    log_debug("clear_cache() called.")
    confirm = xbmcgui.Dialog().yesno('Clear Cache', 'Are you sure you want to clear all cached data?')
    log_debug(f"Confirmation dialog result: {'Yes' if confirm else 'No'}")
    if confirm:
        if os.path.exists(CACHE_FILE):
            try:
                os.remove(CACHE_FILE)
                xbmcgui.Dialog().notification('Cache Cleared', 'All cached data has been removed.', xbmcgui.NOTIFICATION_INFO)
                log_debug("Cache file successfully deleted.")
            except OSError as e:
                xbmcgui.Dialog().notification('Error', f'Failed to delete cache: {e}', xbmcgui.NOTIFICATION_ERROR)
                log_debug(f"Error deleting cache file: {e}")
        else:
            xbmcgui.Dialog().notification('Cache Already Cleared', 'No cache data to remove.', xbmcgui.NOTIFICATION_INFO)
            log_debug("Cache file does not exist.")


def validate_settings():
    if not BASE_URL or not USERNAME or not PASSWORD:
        xbmcgui.Dialog().notification(
            'Settings Error',
            'Please configure Base URL, Username, and Password in settings.',
            xbmcgui.NOTIFICATION_ERROR
        )
        return False
    return True

def log_debug(message):
    masked_message = mask_sensitive_info(message)
    xbmc.log(f"[DEBUG] {masked_message}", level=xbmc.LOGINFO)

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def settings():
    ADDON.openSettings()

def validate_settings():
    if not BASE_URL or not USERNAME or not PASSWORD:
        xbmcgui.Dialog().notification(
            'Settings Error',
            'Please configure Base URL, Username, and Password in settings.',
            xbmcgui.NOTIFICATION_ERROR
        )
        return False
    return True

def request_with_credentials(endpoint):
    if not validate_settings():
        raise ValueError("Invalid settings. Ensure Base URL, Username, and Password are configured.")
    try:
        params = {'username': '***', 'password': '***'}
        url = f"{BASE_URL}{endpoint}"
        
        # Masking sensitive URL parts for logging
        masked_url = mask_sensitive_info(url)
        log_debug(f"Requesting URL: {masked_url} with params: {params}")
        
        response = requests.get(url, params={'username': USERNAME, 'password': PASSWORD}, headers={'User-Agent': 'KodiAddon/1.0'})
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        log_debug(f"API Request Failed: {e}")
        raise

def mask_sensitive_info(url):
    """Masks sensitive information in a URL."""
    if not url:
        return url
    masked_url = url
    if BASE_URL:
        masked_url = masked_url.replace(BASE_URL, '***NOT_SHOWN***')
    if USERNAME:
        masked_url = masked_url.replace(USERNAME, '***')
    if PASSWORD:
        masked_url = masked_url.replace(PASSWORD, '***')
    return masked_url

def main_menu():
    show_live_tv = ADDON.getSettingBool('show_live_tv')
    show_vod = ADDON.getSettingBool('show_vod')
    show_series = ADDON.getSettingBool('show_series')

    menu_items = []
    if show_live_tv:
        menu_items.append(('Live TV', 'live_tv', True))
    if show_vod:
        menu_items.append(('Video on Demand (VOD)', 'vod', True))
    if show_series:
        menu_items.append(('TV Series', 'series', True))
    
    menu_items.append(('Utilities', 'utilities', True))

    for label, action, is_folder in menu_items:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': action}), xbmcgui.ListItem(label), is_folder)
    xbmcplugin.endOfDirectory(HANDLE)


def utilities_menu():
    utilities = [
        ('Addon Settings', 'settings', True),
        ('Account Information', 'account_info', True),
        ('[COLOR=lime]==========TOOLS============[/COLOR]', '', False),
        ('***Speed Test***', 'speed_test', False),
        ('***Clear Cache***', 'clear_cache', True)
    ]
    for label, action, is_folder in utilities:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': action}), xbmcgui.ListItem(label), is_folder)
    xbmcplugin.endOfDirectory(HANDLE)


def live_tv():
    try:
        categories = request_with_cache('/player_api.php?action=get_live_categories')

        for category in categories:
            if FILTER_ADULT and any(keyword in category['category_name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'list_channels', 'category_id': category['category_id']}),
                xbmcgui.ListItem(category['category_name']),
                True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Live TV categories: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in live_tv: {e}")

def list_channels(category_id):
    try:
        channels = request_with_credentials(f'/player_api.php?action=get_live_streams&category_id={category_id}')
        for channel in channels:
            if FILTER_ADULT and any(keyword in channel['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            list_item = xbmcgui.ListItem(channel['name'])
            channel_logo = channel.get('stream_icon', '')
            if channel_logo:
                list_item.setArt({'icon': channel_logo, 'thumb': channel_logo})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play', 'channel_id': channel['stream_id']}),
                list_item,
                False
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch channels: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_channels: {e}")

def play_stream(channel_id):
    try:
        enable_quality_selection = ADDON.getSettingBool('enable_quality_selection')
        max_quality = ADDON.getSetting('max_quality')
        quality_limits = {'0': float('inf'), '1': 1080, '2': 720, '3': 480}
        max_allowed_quality = quality_limits.get(max_quality, float('inf'))
        stream_url = f"{BASE_URL}/live/{USERNAME}/{PASSWORD}/{channel_id}.m3u8"
        log_debug(f"Fetching master playlist: {stream_url}")
        response = requests.get(stream_url)
        response.raise_for_status()
        playlist = m3u8.loads(response.text)
        qualities = []
        for variant in playlist.playlists:
            bandwidth = variant.stream_info.bandwidth // 1000
            resolution = variant.stream_info.resolution
            uri = variant.uri
            if resolution:
                quality_label = f"{resolution[1]}p ({bandwidth} kbps)"
                quality_value = resolution[1]
            else:
                quality_label = f"{bandwidth} kbps"
                quality_value = 0
            qualities.append({'label': quality_label, 'url': uri, 'quality': quality_value})
        filtered_qualities = [q for q in qualities if q['quality'] <= max_allowed_quality]
        if enable_quality_selection and filtered_qualities:
            options = [q['label'] for q in filtered_qualities]
            dialog = xbmcgui.Dialog()
            selected_index = dialog.select("Select Playback Quality", options)
            if selected_index >= 0:
                selected_url = filtered_qualities[selected_index]['url']
                log_debug(f"Playing selected stream: {selected_url}")
                xbmc.Player().play(selected_url)
            else:
                log_debug("Playback canceled by user.")
        else:
            best_quality = max(filtered_qualities, key=lambda q: q['quality'], default=None)
            if best_quality:
                log_debug(f"Playing best available stream: {best_quality['url']}")
                xbmc.Player().play(best_quality['url'])
            else:
                log_debug("No valid quality options found. Playing default stream.")
                xbmc.Player().play(stream_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to play stream: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in play_stream: {e}")

def list_vod_categories():
    try:
        categories = request_with_cache('/player_api.php?action=get_vod_categories')
        for category in categories:
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'list_vod_content', 'category_id': category['category_id']}),
                xbmcgui.ListItem(category['category_name']),
                True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch VOD categories: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_vod_categories: {e}")

def list_vod_content(category_id):
    try:
        contents = request_with_credentials(f'/player_api.php?action=get_vod_streams&category_id={category_id}')
        for content in contents:
            if FILTER_ADULT and any(keyword in content['name'].lower() for keyword in ADULT_KEYWORDS):
                continue
            list_item = xbmcgui.ListItem(content['name'])
            content_logo = content.get('stream_icon', '')
            if content_logo:
                list_item.setArt({'icon': content_logo, 'thumb': content_logo})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play_vod', 'content_id': content['stream_id']}),
                list_item,
                False
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch VOD content: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_vod_content: {e}")

def play_vod(content_id):
    try:
        stream_url = f"{BASE_URL}/movie/{USERNAME}/{PASSWORD}/{content_id}.m3u8"
        log_debug(f"Attempting to play VOD: {stream_url}")
        xbmc.Player().play(stream_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to play VOD: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in play_vod: {e}")

def list_series_categories():
    try:
        categories = request_with_cache('/player_api.php?action=get_series_categories')
        if not categories:
            xbmcgui.Dialog().notification('Error', 'No series categories found.', xbmcgui.NOTIFICATION_ERROR)
            return
        for category in categories:
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'list_series', 'category_id': category['category_id']}),
                xbmcgui.ListItem(category['category_name']),
                True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Series categories: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_series_categories: {e}")

def list_series(category_id):
    try:
        series_list = request_with_credentials(f'/player_api.php?action=get_series&category_id={category_id}')
        if not series_list:
            xbmcgui.Dialog().notification('Error', 'No series found in this category.', xbmcgui.NOTIFICATION_ERROR)
            return
        for series in series_list:
            list_item = xbmcgui.ListItem(series['name'])
            series_logo = series.get('cover', '')
            if series_logo:
                list_item.setArt({'icon': series_logo, 'thumb': series_logo})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'list_seasons', 'series_id': series['series_id']}),
                list_item,
                True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Series: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_series: {e}")

def list_seasons(series_id):
    try:
        series_info = request_with_credentials(f'/player_api.php?action=get_series_info&series_id={series_id}')
        seasons = series_info.get('seasons', [])
        if not seasons:
            xbmcgui.Dialog().notification('Error', 'No seasons found for this series.', xbmcgui.NOTIFICATION_ERROR)
            return
        for season in seasons:
            list_item = xbmcgui.ListItem(season['name'])
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'list_episodes', 'series_id': series_id, 'season_id': season['id']}),
                list_item,
                True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Seasons: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in list_seasons: {e}")

def list_episodes(series_id, season_id):
    try:
        series_info = request_with_credentials(f'/player_api.php?action=get_series_info&series_id={series_id}')
        episodes_by_season = series_info.get('episodes', {})
        episodes = episodes_by_season.get(str(season_id), [])
        if not episodes:
            xbmcgui.Dialog().notification('No Episodes', f'No episodes found for Season {season_id}.', xbmcgui.NOTIFICATION_INFO)
            log_debug(f"No episodes found for season ID: {season_id}")
            return

        for episode in episodes:
            title = episode.get('title', 'Unknown Episode')
            episode_id = episode.get('id')
            description = episode.get('info', {}).get('plot', 'No description available.')
            iconimage = episode.get('info', {}).get('movie_image', '')

            list_item = xbmcgui.ListItem(title)
            list_item.setArt({'icon': iconimage, 'thumb': iconimage})
            info_tag = list_item.getVideoInfoTag()
            info_tag.setTitle(title)
            info_tag.setPlot(description)

            list_item.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(
                HANDLE,
                build_url({'action': 'play_episode', 'series_id': series_id, 'season_id': season_id, 'episode_id': episode_id}),
                list_item,
                False
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        log_debug(f"Error in list_episodes: {e}")
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Episodes: {e}', xbmcgui.NOTIFICATION_ERROR)


def is_m3u8(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'}
        response = requests.head(url, headers=headers, timeout=10)
        log_debug(f"HEAD request response: {response.status_code}, {response.headers}")

        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')
            if 'mpegurl' in content_type.lower():
                log_debug(f"URL is a valid m3u8: {url}")
                return True
        log_debug(f"URL is not a valid m3u8: {content_type}")
        return False
    except Exception as e:
        log_debug(f"Error checking m3u8: {e}")
        return False

def play_episode(series_id, season_id, episode_id, extension="mkv"):
    try:
        stream_url = f"{BASE_URL}/series/{USERNAME}/{PASSWORD}/{episode_id}.{extension}"
        log_debug(f"Constructed stream URL: {stream_url}")

        list_item = xbmcgui.ListItem(path=stream_url)
        list_item.setProperty('IsPlayable', 'true')

        headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
            "Referer": BASE_URL
        }
        list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        list_item.setProperty('inputstream.adaptive.stream_headers', "&".join([f"{k}={v}" for k, v in headers.items()]))

        cookies = f"dns={BASE_URL}; username={USERNAME}; password={PASSWORD}"
        list_item.setProperty('inputstream.adaptive.cookie', cookies)

        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(f"Episode {episode_id}")
        info_tag.setPlot("")

        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    except Exception as e:
        log_debug(f"Error in play_episode: {e}")
        xbmcgui.Dialog().notification('Playback Error', 'Unable to play the episode.', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def check_protocol(url):
    parsed = urlparse(BASE_URL)
    protocol = parsed.scheme
    if protocol == 'https':
        return url.replace('http', 'https')
    return url

def LogNotify(title, message, times=2000, sound=False):
    xbmcgui.Dialog().notification(title, message, int(times), sound)



def account_info():
    try:
        account_details = request_with_credentials('/player_api.php?action=get_account_info')
        user_info = account_details.get('user_info', {})
        username = user_info.get('username', 'Unknown')
        status = user_info.get('status', 'Unknown')
        expiration = user_info.get('exp_date', 'Unknown')
        max_connections = user_info.get('max_connections', 'Unknown')
        active_connections = user_info.get('active_cons', 'Unknown')
        expiration_date = 'Unknown'
        expiration_message = 'Unknown'
        expiration_color = 'red'
        notify = ADDON.getSettingBool('notify_expiring_accounts')
        if expiration.isdigit():
            expiration_timestamp = int(expiration)
            expiration_date = time.strftime('%Y-%m-%d', time.localtime(expiration_timestamp))
            days_remaining = (expiration_timestamp - time.time()) / (24 * 3600)
            if days_remaining <= 0 and notify:
                expiration_message = "Expired"
                xbmcgui.Dialog().notification(
                    'Account Expired',
                    f"Your account expired on {expiration_date}.",
                    xbmcgui.NOTIFICATION_ERROR
                )
            elif days_remaining <= 7 and notify:
                expiration_message = f"{int(days_remaining)} days remaining"
                expiration_color = 'yellow'
                xbmcgui.Dialog().notification(
                    'Account Expiring Soon',
                    f"Your account will expire in {int(days_remaining)} days on {expiration_date}.",
                    xbmcgui.NOTIFICATION_WARNING
                )
            else:
                expiration_message = f"{int(days_remaining)} days remaining"
                expiration_color = 'lime'
        items = [
            f"[B]Username:[/B] [COLOR=lime]{username}[/COLOR]",
            f"[B]Status:[/B] [COLOR=lime]{status}[/COLOR]",
            f"[B]Expiration:[/B] [COLOR={expiration_color}]{expiration_date}[/COLOR] ({expiration_message})",
            f"[B]Max Connections:[/B] [COLOR=lime]{max_connections}[/COLOR]",
            f"[B]Active Connections:[/B] [COLOR=lime]{active_connections}[/COLOR]"
        ]
        for item in items:
            list_item = xbmcgui.ListItem(item)
            list_item.setInfo('video', {})
            xbmcplugin.addDirectoryItem(HANDLE, '', list_item, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Failed to fetch Account Info: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Error in account_info: {e}")

def speed_test():
    from resources.speedtest import run_speed_test
    run_speed_test()
    
if __name__ == '__main__':
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    action = params.get('action', [None])[0]
    try:
        if action is None:
            main_menu()
        elif action == 'live_tv':
            live_tv()
        elif action == 'list_channels':
            list_channels(params['category_id'][0])
        elif action == 'play':
            play_stream(params['channel_id'][0])
        elif action == 'vod':
            list_vod_categories()
        elif action == 'list_vod_content':
            list_vod_content(params['category_id'][0])
        elif action == 'play_vod':
            play_vod(params['content_id'][0])
        elif action == 'series':
            list_series_categories()
        elif action == 'list_series':
            list_series(params['category_id'][0])
        elif action == 'list_seasons':
            list_seasons(params['series_id'][0])
        elif action == 'list_episodes':
            list_episodes(params['series_id'][0], params['season_id'][0])
        elif action == 'play_episode':
            play_episode(params['series_id'][0], params['season_id'][0], params['episode_id'][0])
        elif action == 'account_info':
            account_info()
        elif action == 'settings':
            settings()
        elif action == 'speed_test':
            speed_test()
        elif action == 'clear_cache':
            clear_cache()
        elif action == 'utilities':
            utilities_menu()
        else:
            xbmcgui.Dialog().notification('Error', f'Unknown action: {action}', xbmcgui.NOTIFICATION_ERROR)
            log_debug(f"Unknown action: {action}")
    except Exception as e:
        xbmcgui.Dialog().notification('Error', f'Unhandled exception: {e}', xbmcgui.NOTIFICATION_ERROR)
        log_debug(f"Unhandled exception: {e}")
