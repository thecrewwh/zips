
import base64, codecs
thecrew = 'ZGVmIGNsZWFuX25hbWUobmFtZSk6DQoJbmFtZSA9IG5hbWUucmVwbGFjZSgnJmFtcDsnLCcmJykucmVwbGFjZSgnY'
doesnt = 'J1jBlpfWlpcYaWypTkuL2HbWlZjZmx7WljaKPpaXF5lMKOfLJAyXPpzLJA1qTH7WljaKPpaXF5lMKOfLJAyXPpzKP'
do = 'cnLCdcJycpLnJlcGxhY2UoJyZxdW90OycsJyInKS5yZXBsYWNlKCc8L2Rpdj4nLCcnKQ0KCW5hbWUgPSBuYW1lLnJ'
drama = 'ypTkuL2HbW1khWljaWlxhpzIjoTSwMFtaCTxtL2kup3Z9Vzywo25snTDvCwjinG4aYPpaXD0XPKWyqUIlovOhLJ1y'
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))