
import base64, codecs
thecrew = 'aW1wb3J0IHhibWMNCmZyb20gcmVzb3VyY2VzLmxpYi5fYWRkb24gaW1wb3J0ICoNCg0KZGVmIExvZyhtc2cpOg0KCWlmIHNldHRpbmdfdHJ1ZSgnZGVid'
doesnt = 'JpaXGbAPtxWMaWioFOcoaAjMJA0VTygpT9lqPOaMKEzpzSgMJyhMz8fVUA0LJAeQDbWPJMcoTIcozMiVQ0tM2I0MaWuoJIcozMiXUA0LJAeXPyoZI1oZS'
do = '0pDQoJCXhibWMubG9nKCcqX197fV9fe30qe30gUHl0aG9uIGZpbGUgbmFtZSA9IHt9IExpbmUgTnVtYmVyID0ge30nLmZvcm1hdChhZGRvbl9uYW1lLGF'
drama = 'xMT9hK3MypaAco24foKAaYTMcoTIcozMiYzMcoTIhLJ1yYTMcoTIcozMiYzkcozIholxfVTkyqzIfCKuvoJZhGR9UGx9HFHASXD0XPJIfp2H6pTSmpj=='
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))