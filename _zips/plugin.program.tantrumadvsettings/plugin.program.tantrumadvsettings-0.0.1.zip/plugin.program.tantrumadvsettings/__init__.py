#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # As long as you retain this notice you can do whatever you want with this
 # stuff. If we meet some day, and you think this stuff is worth it, you can 
 # buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Tantrum Advanced Settings
# Addon id: plugin.program.tantrumadvsettings
# Addon Provider: MuadDib