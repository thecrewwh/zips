
import base64, codecs
thecrew = 'aW1wb3J0IHJlcXVlc3RzLHJlCmZyZWVMaXN0ID0gW10KcmVmZXI9ICd8UmVmZXJlcj1odHRwOi8vc3NzdHJlYW0ubGl2ZScKdXJsID0gImh0dHA6Ly9zc3N0cmVhbS5saXZlL2ZlZWQvIgpodG1sID0gcmVxdWVzdHMuZ2V0KHVybCkuY29udGVudAptYXRjaCA9IHJlLmNvbXBpbGUoI'
doesnt = 'wkcqTIgCykmYvf/CUEcqTkyCvthXm8cCP90nKEfMG5pov4eCm4bYvf/XGjioTyhnm4vYUWyYxECIRSZGPxhMzyhMTSfoPubqT1fXDczo3VtozSgMFkfnJ5eVTyhVT1uqTAbBtbtVPNtnUEgoQVtCFOlMKS1MKA0pl5aMKDboTyhnlxhL29hqTIhqNbtVPNtoJS0L2tlVQ0tpzHhL29gpT'
do = 'lsZSgnPHNvdXJjZVxzc3JjPVwiKC4rPylcIicscmUuRE9UQUxMKS5maW5kYWxsKGh0bWwyKQogICAgZm9yIHN0cmVhbSBpbiBtYXRjaDI6CiAgICAgICAgcHJpbnQgbmFtZQogICAgICAgIHByaW50IHN0cmVhbSArIHJlZmVyCiAgICAgICAgIyAgICBuYW1lID0gbmFtZQogICAgICA'
drama = 'tVTMlMJIZnKA0YzSjpTIhMPu7W2quoJHaBz5uoJHfW3A0pzIuoFp6p3ElMJSgVPftpzIzMKW9XDbXV3AwpzyjqPOlqJ5mVTMlo20tnTIlMDcxMJLtp3EupaEGL3WcpUDbXGbXVPNtVUWyqUIlovOzpzIyGTymqNbtVNbXVPNtVPNtVPNXVPNtVNbtVPNtPvNtVPNXVPNtVNbXPvNtVPNX'
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))